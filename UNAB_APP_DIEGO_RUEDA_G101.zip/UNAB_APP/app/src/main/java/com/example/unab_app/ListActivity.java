package com.example.unab_app;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.ListView;

import com.example.unab_app.Adaptadores.ProductoAdaptador;
import com.example.unab_app.Entidaes.Producto;

import java.util.ArrayList;

public class ListActivity extends AppCompatActivity {
    private ListView listViewProducts;
    private ArrayList<Producto> listaProductos;
    private ProductoAdaptador adaptador;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_list);

        listViewProducts = (ListView) findViewById(R.id.listViewProducts);

        listaProductos = new ArrayList<>();
        int img = R.drawable.bota;
        Producto producto1 = new Producto(1,img,"Producto1", "Descripción 1", 10000 );
        Producto producto2 = new Producto(2,img,"Producto2", "Descripción 2", 15000 );
        Producto producto3 = new Producto(3,img,"Producto3", "Descripción 3", 20000 );

        listaProductos.add(producto1);
        listaProductos.add(producto2);
        listaProductos.add(producto3);

        adaptador = new ProductoAdaptador(getApplicationContext(), listaProductos);
        listViewProducts.setAdapter(adaptador);

    }

    public void login(View view){

        Intent login = new Intent(this, MainActivity.class);
        startActivity(login);

    }
}