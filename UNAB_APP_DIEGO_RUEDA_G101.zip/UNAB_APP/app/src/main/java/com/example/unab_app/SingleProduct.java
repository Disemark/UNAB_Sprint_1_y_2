package com.example.unab_app;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;

public class SingleProduct extends AppCompatActivity {

    private ImageView singleImgProduct;
    private TextView singlePrice, singleName, singleDescription;
    private Button singleButton;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_single_product);

        singleButton = (Button) findViewById(R.id.singleButton);
        singlePrice = (TextView) findViewById(R.id.singlePrice);
        singleName = (TextView) findViewById(R.id.singleName);
        singleDescription = (TextView) findViewById(R.id.singleDescription);
        singleImgProduct = (ImageView) findViewById(R.id.singleImgProduct);

        Intent intentIN = getIntent();
        singleName.setText(intentIN.getStringExtra("name"));
        singlePrice.setText(String.valueOf(intentIN.getIntExtra("price", 0)));
        singleDescription.setText(intentIN.getStringExtra("description"));
        singleImgProduct.setImageResource(intentIN.getIntExtra("image", 0));

        singleButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(getApplicationContext(), ListActivity.class);
                startActivity(intent);
            }
        });

    }
}