package com.example.unab_app.Adaptadores;

import android.content.Context;
import android.content.Intent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;

import com.example.unab_app.Entidaes.Producto;
import com.example.unab_app.R;
import com.example.unab_app.SingleProduct;

import java.util.ArrayList;

public class ProductoAdaptador extends BaseAdapter {
    Context context;
    ArrayList<Producto> listaProductos;
    LayoutInflater inflater;

    public ProductoAdaptador(Context context, ArrayList<Producto> listaProductos){
        this.context = context;
        this.listaProductos = listaProductos;
    }

    @Override
    public int getCount() {
        return listaProductos.size();
    }

    @Override
    public Object getItem(int i) {
        return null;
    }

    @Override
    public long getItemId(int i) {
        return 0;
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {

        if (inflater == null){
            inflater = (LayoutInflater) context.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
        }

        if (convertView == null){
            convertView = inflater.inflate(R.layout.product_item, null);
        }

        ImageView productImg = (ImageView) convertView.findViewById(R.id.productImg);
        TextView productName = (TextView) convertView.findViewById(R.id.productName);
        TextView productDescription = (TextView) convertView.findViewById(R.id.productDescription);
        TextView productPrice = (TextView) convertView.findViewById(R.id.productPrice);
        Button productButton = (Button) convertView.findViewById(R.id.productButton);

        Producto producto = listaProductos.get(position);

        productImg.setImageResource(producto.getImage());
        productName.setText(producto.getName());
        productDescription.setText(producto.getDescription());
        productPrice.setText(String.valueOf(producto.getPrice()));
        productButton.setText("Ver");

        productButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(context.getApplicationContext(), SingleProduct.class);
                intent.putExtra("name", producto.getName());
                intent.putExtra("description", producto.getDescription());
                intent.putExtra("price", producto.getPrice());
                intent.putExtra("image", producto.getImage());
                intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                context.startActivity(intent);
            }
        });

        productImg.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(context.getApplicationContext(), SingleProduct.class);
                intent.putExtra("name", producto.getName());
                intent.putExtra("description", producto.getDescription());
                intent.putExtra("price", producto.getPrice());
                intent.putExtra("image", producto.getImage());
                intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                context.startActivity(intent);
            }
        });

        return convertView;
    }
}
